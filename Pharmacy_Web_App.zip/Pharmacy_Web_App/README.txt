MEDICINE EXPIRY AND PHARMACY STOCK ALERT SYSTEM - WEB VERSION

This is a browser-based Flask version prepared from the supplied Tkinter project.
It includes login, inventory dashboard, search, add/edit/delete batch, expiry alerts,
expired stock alerts and low-stock alerts.

IMPORTANT: This is the web application source code, not a deployed public website yet.
You must deploy it and configure a cloud MySQL database to get a shareable URL.
Your local MySQL database at localhost cannot be reached by an online hosting service.

FILES
- app.py: Flask application
- templates/: browser pages
- static/style.css: responsive styling
- schema.sql: cloud database tables and demo admin account
- requirements.txt: Python dependencies
- render.yaml: deployment configuration template

LOCAL TEST (optional)
1. Install Python 3.11 or 3.12.
2. Open a terminal in this folder.
3. Run: py -m pip install -r requirements.txt
4. Set environment variables for DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME.
   For a local database: DB_HOST=localhost, DB_PORT=3306, DB_NAME=pharmacy_management.
5. Run: py app.py
6. Open http://127.0.0.1:5000 in your browser.

ONLINE DEPLOYMENT OVERVIEW
1. Create a managed cloud MySQL database with a provider that supports external connections.
2. Open that database's SQL console and run schema.sql. Keep the host, port, username and
   password private; do not put them in public code or screenshots.
3. Upload this folder to a private GitHub repository (do not upload .env files or secrets).
4. Create a Web Service on Render connected to that repository. Build command:
   pip install -r requirements.txt
   Start command: gunicorn app:app
5. In Render Environment, set DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME and a strong
   SECRET_KEY using the values from your cloud MySQL provider.
6. Deploy. Open the generated Render URL and test login, CRUD and alerts.

DEMO LOGIN (created by schema.sql)
Username: admin
Password: Admin@123
Change the demo password before using real data. This sample is for a college project;
do not store real patient information or sensitive commercial data without proper security.

SECURITY NOTE
This app keeps compatibility with the original project's SHA-256 password hashes. For a
real production system, replace this with a modern password-hashing scheme such as Argon2
or Werkzeug's password hashing helpers, add CSRF protection, and use least-privilege DB
credentials. Never publish database credentials.
