import os
import hashlib
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from functools import wraps

import mysql.connector
from mysql.connector import Error
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deployment")


def get_connection():
    """Read cloud database settings from environment variables; never hard-code credentials."""
    return mysql.connector.connect(
        host=os.environ.get("DB_HOST", "localhost"),
        port=int(os.environ.get("DB_PORT", "3306")),
        user=os.environ.get("DB_USER", "root"),
        password=os.environ.get("DB_PASSWORD", ""),
        database=os.environ.get("DB_NAME", "pharmacy_management"),
        connection_timeout=10,
    )


def hash_password(password):
    # Kept compatible with the SHA-256 hashes used by the original Tkinter project.
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def close_db(cursor, connection):
    if cursor is not None:
        cursor.close()
    if connection is not None and connection.is_connected():
        connection.close()


@app.route("/", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not username or not password:
            flash("Enter both username and password.", "error")
            return render_template("login.html")
        connection = cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor(dictionary=True)
            cursor.execute(
                "SELECT user_id, username FROM users WHERE username=%s AND password_hash=%s",
                (username, hash_password(password)),
            )
            user = cursor.fetchone()
            if user:
                session.clear()
                session["user_id"] = user["user_id"]
                session["username"] = user["username"]
                return redirect(url_for("dashboard"))
            flash("Incorrect username or password.", "error")
        except Error:
            app.logger.exception("Login database error")
            flash("Could not connect to the database. Check the database environment settings.", "error")
        finally:
            close_db(cursor, connection)
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    search = request.args.get("q", "").strip()
    connection = cursor = None
    rows = []
    stats = {"batches": 0, "low": 0, "soon": 0, "expired": 0}
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        sql = """SELECT m.medicine_id, m.medicine_name, m.category, m.manufacturer,
                         b.batch_id, b.batch_number, b.quantity, b.price, b.expiry_date
                  FROM medicines m JOIN medicine_batches b ON b.medicine_id=m.medicine_id"""
        params = []
        if search:
            sql += " WHERE m.medicine_name LIKE %s OR b.batch_number LIKE %s OR m.category LIKE %s"
            term = f"%{search}%"
            params = [term, term, term]
        sql += " ORDER BY b.expiry_date ASC, m.medicine_name ASC"
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS n FROM medicine_batches")
        stats["batches"] = cursor.fetchone()["n"]
        cursor.execute("SELECT COUNT(*) AS n FROM medicine_batches WHERE quantity <= 10")
        stats["low"] = cursor.fetchone()["n"]
        cursor.execute("SELECT COUNT(*) AS n FROM medicine_batches WHERE expiry_date >= %s AND expiry_date <= %s", (date.today(), date.today()+timedelta(days=30)))
        stats["soon"] = cursor.fetchone()["n"]
        cursor.execute("SELECT COUNT(*) AS n FROM medicine_batches WHERE expiry_date < %s", (date.today(),))
        stats["expired"] = cursor.fetchone()["n"]
    except Error:
        app.logger.exception("Dashboard database error")
        flash("Unable to load inventory. Check your database settings and tables.", "error")
    finally:
        close_db(cursor, connection)
    return render_template("dashboard.html", rows=rows, stats=stats, search=search, today=date.today())


def validate_medicine_form(form):
    name = form.get("medicine_name", "").strip()
    category = form.get("category", "").strip()
    manufacturer = form.get("manufacturer", "").strip()
    batch = form.get("batch_number", "").strip()
    try:
        quantity = int(form.get("quantity", ""))
        price = Decimal(form.get("price", ""))
        expiry = date.fromisoformat(form.get("expiry_date", ""))
    except (ValueError, InvalidOperation):
        raise ValueError("Enter a whole-number quantity, a valid price, and an expiry date.")
    if not all([name, category, manufacturer, batch]):
        raise ValueError("Please fill in all fields.")
    if quantity < 0:
        raise ValueError("Quantity cannot be negative.")
    if not price.is_finite() or price < 0 or price > Decimal("99999999.99"):
        raise ValueError("Enter a valid price.")
    if expiry < date.today():
        raise ValueError("Expiry date cannot be in the past. Expired stock can be recorded by an administrator directly in the database for testing alerts.")
    return name, category, manufacturer, batch, quantity, price, expiry


@app.route("/medicine/add", methods=["GET", "POST"])
@login_required
def add_medicine():
    if request.method == "POST":
        connection = cursor = None
        try:
            values = validate_medicine_form(request.form)
            name, category, manufacturer, batch, quantity, price, expiry = values
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO medicines (medicine_name, category, manufacturer) VALUES (%s,%s,%s)", (name, category, manufacturer))
            medicine_id = cursor.lastrowid
            cursor.execute("INSERT INTO medicine_batches (medicine_id, batch_number, quantity, price, expiry_date) VALUES (%s,%s,%s,%s,%s)", (medicine_id, batch, quantity, price, expiry))
            connection.commit()
            flash("Medicine batch added successfully.", "success")
            return redirect(url_for("dashboard"))
        except ValueError as e:
            flash(str(e), "error")
        except Error as e:
            if connection:
                connection.rollback()
            app.logger.exception("Add medicine database error")
            flash("Could not save this batch. Check for a duplicate batch number or database issue.", "error")
        finally:
            close_db(cursor, connection)
    return render_template("medicine_form.html", mode="Add", row=None)


@app.route("/medicine/<int:batch_id>/edit", methods=["GET", "POST"])
@login_required
def edit_medicine(batch_id):
    connection = cursor = None
    row = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""SELECT m.medicine_id, m.medicine_name, m.category, m.manufacturer,
                                 b.batch_id, b.batch_number, b.quantity, b.price, b.expiry_date
                          FROM medicines m JOIN medicine_batches b ON b.medicine_id=m.medicine_id
                          WHERE b.batch_id=%s""", (batch_id,))
        row = cursor.fetchone()
    except Error:
        app.logger.exception("Edit lookup database error")
        flash("Unable to retrieve this medicine batch.", "error")
        return redirect(url_for("dashboard"))
    finally:
        close_db(cursor, connection)
    if row is None:
        flash("Medicine batch not found.", "error")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        connection = cursor = None
        try:
            name, category, manufacturer, batch, quantity, price, expiry = validate_medicine_form(request.form)
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT batch_id FROM medicine_batches WHERE medicine_id=%s AND batch_number=%s AND batch_id<>%s", (row["medicine_id"], batch, batch_id))
            if cursor.fetchone():
                flash("That batch number already exists for this medicine.", "error")
                return render_template("medicine_form.html", mode="Edit", row={**row, "medicine_name": name, "category": category, "manufacturer": manufacturer, "batch_number": batch, "quantity": quantity, "price": price, "expiry_date": expiry})
            cursor.execute("UPDATE medicines SET medicine_name=%s, category=%s, manufacturer=%s WHERE medicine_id=%s", (name, category, manufacturer, row["medicine_id"]))
            cursor.execute("UPDATE medicine_batches SET batch_number=%s, quantity=%s, price=%s, expiry_date=%s WHERE batch_id=%s", (batch, quantity, price, expiry, batch_id))
            connection.commit()
            flash("Medicine batch updated successfully.", "success")
            return redirect(url_for("dashboard"))
        except ValueError as e:
            flash(str(e), "error")
        except Error:
            if connection:
                connection.rollback()
            app.logger.exception("Update medicine database error")
            flash("Could not update the medicine batch.", "error")
        finally:
            close_db(cursor, connection)
        return render_template("medicine_form.html", mode="Edit", row=row)
    return render_template("medicine_form.html", mode="Edit", row=row)


@app.route("/medicine/<int:batch_id>/delete", methods=["POST"])
@login_required
def delete_medicine(batch_id):
    connection = cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("DELETE FROM medicine_batches WHERE batch_id=%s", (batch_id,))
        connection.commit()
        flash("Medicine batch deleted.", "success" if cursor.rowcount else "error")
        if cursor.rowcount == 0:
            flash("Batch not found.", "error")
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Delete medicine database error")
        flash("Could not delete this batch.", "error")
    finally:
        close_db(cursor, connection)
    return redirect(url_for("dashboard"))


@app.route("/alerts/<kind>")
@login_required
def alerts(kind):
    if kind not in ("expiry", "low-stock", "expired"):
        return redirect(url_for("dashboard"))
    connection = cursor = None
    rows = []
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        sql = """SELECT m.medicine_name, m.category, b.batch_id, b.batch_number,
                         b.quantity, b.price, b.expiry_date
                  FROM medicines m JOIN medicine_batches b ON b.medicine_id=m.medicine_id"""
        if kind == "expiry":
            sql += " WHERE b.expiry_date >= %s AND b.expiry_date <= %s ORDER BY b.expiry_date"
            cursor.execute(sql, (date.today(), date.today()+timedelta(days=30)))
            title = "Expiring in the Next 30 Days"
        elif kind == "expired":
            sql += " WHERE b.expiry_date < %s ORDER BY b.expiry_date"
            cursor.execute(sql, (date.today(),))
            title = "Expired Medicines"
        else:
            sql += " WHERE b.quantity <= 10 ORDER BY b.quantity ASC"
            cursor.execute(sql)
            title = "Low Stock (10 or Fewer)"
        rows = cursor.fetchall()
    except Error:
        app.logger.exception("Alerts database error")
        flash("Unable to load alerts. Check database settings.", "error")
        title = "Alerts"
    finally:
        close_db(cursor, connection)
    return render_template("alerts.html", rows=rows, title=title, kind=kind, today=date.today())


@app.route("/health")
def health():
    """Simple deployment check; does not expose database credentials."""
    connection = None
    try:
        connection = get_connection()
        return {"status": "ok", "database": "connected"}, 200
    except Error:
        return {"status": "error", "database": "unavailable"}, 503
    finally:
        if connection and connection.is_connected():
            connection.close()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
