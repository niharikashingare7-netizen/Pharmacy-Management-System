-- Run these statements in your CLOUD MySQL database (not only on localhost).
-- If you already created the same tables, do not run CREATE TABLE again unless needed.
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS medicines (
  medicine_id INT AUTO_INCREMENT PRIMARY KEY,
  medicine_name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  manufacturer VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS medicine_batches (
  batch_id INT AUTO_INCREMENT PRIMARY KEY,
  medicine_id INT NOT NULL,
  batch_number VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  expiry_date DATE NOT NULL,
  FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id),
  UNIQUE (medicine_id, batch_number),
  CHECK (quantity >= 0),
  CHECK (price >= 0)
);

-- Creates the same demo admin login as the desktop version:
-- username: admin; password: Admin@123
INSERT INTO users (username, password_hash)
SELECT 'admin', SHA2('Admin@123', 256)
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');
